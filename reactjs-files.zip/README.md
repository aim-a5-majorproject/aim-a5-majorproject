# ReactJS Starter

A simple React application created with React and Vite.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```
