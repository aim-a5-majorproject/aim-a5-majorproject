import { useState } from 'react';

export default function App() {
  const [count, setCount] = useState(0);

  return (
    <main className="container">
      <section className="card">
        <p className="eyebrow">REACTJS STARTER</p>
        <h1>Hello, React! 👋</h1>
        <p>This is a simple React application built with Vite.</p>
        <button onClick={() => setCount((value) => value + 1)}>
          Clicked {count} times
        </button>
      </section>
    </main>
  );
}