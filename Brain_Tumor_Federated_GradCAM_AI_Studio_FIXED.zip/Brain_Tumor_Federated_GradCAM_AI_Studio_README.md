# Federated Brain Tumor MRI — Fixed Grad-CAM AI Studio

Upload the .ipynb to Google Colab, select GPU, run cells sequentially. The notebook downloads the Kaggle brain tumor MRI dataset, creates four simulated non-IID hospital clients, trains a federated global model with FedAvg/FedProx/SCAFFOLD, evaluates the checkpoint, then launches a Gradio MRI classifier with Grad-CAM.

The original notebook defaults to EfficientNet-B0 and FedAvg/FedProx, with optional ResNet-18 and VGG16. Change RUN_FULL_GRID=True to enable the larger grid. For a smoke test, reduce ROUNDS to 1. The checkpoint is stored under /content/brain_fl_results; copy it to Google Drive before resetting the runtime.

Important: Only source-code syntax and notebook structure were validated here. Full GPU training and live Gradio upload were not run. This is a research-only demo, not a diagnostic device. No secure aggregation, DP, DICOM/NIfTI support, real hospital networking, or validated tumor segmentation.
