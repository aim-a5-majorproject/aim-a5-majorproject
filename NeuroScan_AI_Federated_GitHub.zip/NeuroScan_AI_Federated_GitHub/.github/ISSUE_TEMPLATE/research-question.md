---
name: Research question
about: Track a NeuroScan research question
title: "[RESEARCH] "
labels: research
---

## Question

## Hypothesis

## Why it matters

## Proposed experiment

## Metrics

## Expected evidence
