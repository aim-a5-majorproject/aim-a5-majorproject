---
name: Planned experiment
about: Define a reproducible federated-learning experiment
title: "[EXPERIMENT] "
labels: experiment
---

## Objective

## Dataset/client configuration

## Model configuration

## Federated configuration

## Evaluation metrics

## Reproducibility notes
