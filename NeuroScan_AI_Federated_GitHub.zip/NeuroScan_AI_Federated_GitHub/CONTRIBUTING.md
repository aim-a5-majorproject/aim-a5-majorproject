# Contributing

1. Create a feature branch.
2. Keep raw datasets, patient information, credentials, and trained model binaries out of Git.
3. Add or update tests for reusable Python modules.
4. Document experiment configuration and report measured results.
5. Open a pull request describing the change and its effect on reproducibility.

For research experiments, record dataset version, random seed, model configuration, federated rounds, local epochs, and evaluation method.
