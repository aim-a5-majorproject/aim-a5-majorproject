# Evaluation artifacts

The supplied notebook generates:

- `metrics.json`
- `federated_history.csv`
- `hospital_results.csv`

These are generated from the actual training/evaluation run and should not be replaced by invented target metrics.
