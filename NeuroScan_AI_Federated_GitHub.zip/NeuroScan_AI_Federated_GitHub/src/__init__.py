"""Core NeuroScan AI research utilities."""
