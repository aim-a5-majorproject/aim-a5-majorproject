# Models

After running the Colab notebook, copy:

`neuroscan_fedavg_vgg16.keras`

into this directory.

Large trained model files are excluded by `.gitignore`.
